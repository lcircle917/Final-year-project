clear all; close all
clc
%% 
data_len=600;

% thermal comfort vote - 3 scale
tcv_cold=zeros(data_len,1);
tcv_cold(:,:)=-1;
tcv_neutral=zeros(data_len,1);
tcv_neutral(:,:)=0;
tcv_hot=zeros(data_len,1);
tcv_hot(:,:)=1;

%%% combine all the features into an array in the order of:
%%%  TSV、T_air、T_skin、heart rate、GSR
% 16℃
data=load('hardware_test_III/16℃/heavy_clothes_cold/data_1.mat');
data16_1 = data.data(:,601:1200)';
data16_1=[tcv_cold,data16_1];
data=load('hardware_test_III/16℃/light_clothes_cold/data_2.mat');
data16_2 = data.data(:,601:1200)';
data16_2=[tcv_cold,data16_2];
data=load('hardware_test_III/16℃/light_clothes+fan_cold/data_3.mat');
data16_3 = data.data(:,601:1200)';
data16_3=[tcv_cold,data16_3];

% 18℃
data=load('hardware_test_III/18℃/heavy_clothes_cold/data_4.mat');
data18_1 = data.data(:,601:1200)';
data18_1=[tcv_cold,data18_1];
data=load('hardware_test_III/18℃/light_clothes_cold/data_5.mat');
data18_2 = data.data(:,601:1200)';
data18_2=[tcv_cold,data18_2];
data=load('hardware_test_III/18℃/light_clothes+fan_cold/data_6.mat');
data18_3 = data.data(:,601:1200)';
data18_3=[tcv_cold,data18_3];

% 20℃
data=load('hardware_test_III/20℃/heavy_clothes_cold/data_7.mat');
data20_1 = data.data(:,601:1200)';
data20_1=[tcv_cold,data20_1];
data=load('hardware_test_III/20℃/light_clothes_cold/data_8.mat');
data20_2 = data.data(:,601:1200)';
data20_2=[tcv_cold,data20_2];
data=load('hardware_test_III/20℃/light_clothes+fan_cold/data_9.mat');
data20_3 = data.data(:,601:1200)';
data20_3=[tcv_cold,data20_3];

% 22℃
data=load('hardware_test_III/22℃/heavy_clothes_neutral/data_10.mat');
data22_1 = data.data(:,601:1200)';
data22_1=[tcv_neutral,data22_1];
data=load('hardware_test_III/22℃/light_clothes_cold/data_11.mat');
data22_2 = data.data(:,601:1200)';
data22_2=[tcv_cold,data22_2];
data=load('hardware_test_III/22℃/light_clothes+fan_cold/data_12.mat');
data22_3 = data.data(:,601:1200)';
data22_3=[tcv_cold,data22_3];

% 24℃
data=load('hardware_test_III/24℃/heavy_clothes_neutral/data_13.mat');
data24_1 = data.data(:,601:1200)';
data24_1=[tcv_neutral,data24_1];
data=load('hardware_test_III/24℃/light_clothes_cold/data_14.mat');
data24_2 = data.data(:,601:1200)';
data24_2=[tcv_cold,data24_2];
data=load('hardware_test_III/24℃/light_clothes+fan_cold/data_15.mat');
data24_3 = data.data(:,601:1200)';
data24_3=[tcv_cold,data24_3];

% 26℃
data=load('hardware_test_III/26℃/heavy_clothes_neutral/data_16.mat');
data26_1 = data.data(:,601:1200)';
data26_1=[tcv_neutral,data26_1];
data=load('hardware_test_III/26℃/light_clothes_neutral/data_17.mat');
data26_2 = data.data(:,601:1200)';
data26_2=[tcv_neutral,data26_2];
data=load('hardware_test_III/26℃/light_clothes+fan_cold/data_18.mat');
data26_3 = data.data(:,601:1200)';
data26_3=[tcv_cold,data26_3];

% 28℃
data=load('hardware_test_III/28℃/heavy_clothes_hot/data_19.mat');
data28_1 = data.data(:,601:1200)';
data28_1=[tcv_hot,data28_1];
data=load('hardware_test_III/28℃/light_clothes_neutral/data_20.mat');
data28_2 = data.data(:,601:1200)';
data28_2=[tcv_neutral,data28_2];
data=load('hardware_test_III/28℃/light_clothes+fan_neutral/data_21.mat');
data28_3 = data.data(:,601:1200)';
data28_3=[tcv_neutral,data28_3];

% 30℃
data=load('hardware_test_III/30℃/heavy_clothes_hot/data_22.mat');
data30_1 = data.data(:,601:1200)';
data30_1=[tcv_hot,data30_1];
data=load('hardware_test_III/30℃/light_clothes_hot/data_23.mat');
data30_2 = data.data(:,601:1200)';
data30_2=[tcv_hot,data30_2];
data=load('hardware_test_III/30℃/light_clothes+fan_neutral/data_24.mat');
data30_3 = data.data(:,601:1200)';
data30_3=[tcv_neutral,data30_3];

% 32℃
data=load('hardware_test_III/32℃/heavy_clothes_hot/data_25.mat');
data32_1 = data.data(:,601:1200)';
data32_1=[tcv_hot,data32_1];
data=load('hardware_test_III/32℃/light_clothes_hot/data_26.mat');
data32_2 = data.data(:,601:1200)';
data32_2=[tcv_hot,data32_2];
data=load('hardware_test_III/32℃/light_clothes+fan_neutral/data_27.mat');
data32_3 = data.data(:,601:1200)';
data32_3=[tcv_neutral,data32_3];

% 34℃
data=load('hardware_test_III/34℃/heavy_clothes_hot/data_28.mat');
data34_1 = data.data(:,601:1200)';
data34_1=[tcv_hot,data34_1];
data=load('hardware_test_III/34℃/light_clothes_hot/data_29.mat');
data34_2 = data.data(:,601:1200)';
data34_2=[tcv_hot,data34_2];
data=load('hardware_test_III/34℃/light_clothes+fan_neutral/data_30.mat');
data34_3 = data.data(:,601:1200)';
data34_3=[tcv_neutral,data34_3];

% 36℃
data=load('hardware_test_III/36℃/heavy_clothes_hot/data_31.mat');
data36_1 = data.data(:,601:1200)';
data36_1=[tcv_hot,data36_1];
data=load('hardware_test_III/36℃/light_clothes_hot/data_32.mat');
data36_2 = data.data(:,601:1200)';
data36_2=[tcv_hot,data36_2];
data=load('hardware_test_III/36℃/light_clothes+fan_hot/data_33.mat');
data36_3 = data.data(:,601:1200)';
data36_3=[tcv_hot,data36_3];

% 38℃
data=load('hardware_test_III/38℃/heavy_clothes_hot/data_34.mat');
data38_1 = data.data(:,601:1200)';
data38_1=[tcv_hot,data38_1];
data=load('hardware_test_III/38℃/light_clothes_hot/data_35.mat');
data38_2 = data.data(:,601:1200)';
data38_2=[tcv_hot,data38_2];
data=load('hardware_test_III/38℃/light_clothes+fan_hot/data_36.mat');
data38_3 = data.data(:,601:1200)';
data38_3=[tcv_hot,data38_3];

% 40℃
data=load('hardware_test_III/40℃/heavy_clothes_hot/data_37.mat');
data40_1 = data.data(:,601:1200)';
data40_1=[tcv_hot,data40_1];
data=load('hardware_test_III/40℃/light_clothes_hot/data_38.mat');
data40_2 = data.data(:,601:1200)';
data40_2=[tcv_hot,data40_2];
data=load('hardware_test_III/40℃/light_clothes+fan_hot/data_39.mat');
data40_3 = data.data(:,601:1200)';
data40_3=[tcv_hot,data40_3];

% Stack all the results
overalldata_inorder=[data16_1;data16_2;data16_3;data18_1;data18_2;data18_3;
    data20_1;data20_2;data20_3;data22_1;data22_2;data22_3;data24_1;data24_2;data24_3;
    data26_1;data26_2;data26_3;data28_1;data28_2;data28_3;data30_1;data30_2;data30_3;
    data32_1;data32_2;data32_3;data34_1;data34_2;data34_3;data36_1;data36_2;data36_3;
    data38_1;data38_2;data38_3;data40_1;data40_2;data40_3];

%%% Shuffle the matrix by row
rowrank = randperm(size(overalldata_inorder, 1)); % randomly shuffle the row, return the rowrank
overalldata_random = overalldata_inorder(rowrank, :); %%rearrange the data matrix by rowrank

%% Save data into the excel file
% writematrix(overalldata_inorder,'Data collection.xlsx','Sheet','Inorder','Range','A2');
% writematrix(overalldata_random,'Data collection.xlsx','Sheet','Disorder','Range','A2');




%% Adding some exercise data (hardware_test II: Experiments 6-9)

% All 4 experiments lasted 30 minutes in total:
% Rest for the first 10 minutes and the last 10 minutes (rest: 0-10 mins + 20-30 mins)
% The middle 10 minutes are under exercise conditions (exercise: 10-20 mins)
% Data is recorded every seconds

% The data of the first 5 minutes is discarded to ensure the reliability of 
% the data because it takes a certain time for the sensor to stabilize
data_len = (30-5)*60;

% thermal sensation vote - 3 scale
tcv_cold=zeros(data_len,1);
tcv_cold(:,:)=-1;
tcv_neutral=zeros(data_len,1);
tcv_neutral(:,:)=0;
tcv_hot=zeros(data_len,1);
tcv_hot(:,:)=1;

% Load and combine data
data=load('hardware_test_II/experiment_6/data_6.mat');
data6_rest1 = data.data(:,301:600)'; % 5-10 mins: rest 
data6_exercise = data.data(:,601:1200)'; % 10-20 mins: exerices
data6_rest2 = data.data(:,1201:end)'; % 20-30 mins; rest
% Add the corresponding thermal sensation vote
data6 = [tcv_neutral(1:length(data6_rest1),:),data6_rest1;
         tcv_hot(1:length(data6_exercise),:),data6_exercise;
         tcv_neutral(1:length(data6_rest2),:),data6_rest2;];

data=load('hardware_test_II/experiment_7/data_7.mat');
data7_rest1 = data.data(:,301:600)'; % 5-10 mins: rest 
data7_exercise = data.data(:,601:1200)'; % 10-20 mins: exerices
data7_rest2 = data.data(:,1201:end)'; % 20-30 mins; rest
% Add the corresponding thermal sensation vote
data7 = [tcv_neutral(1:length(data7_rest1),:),data7_rest1;
         tcv_hot(1:length(data7_exercise),:),data7_exercise;
         tcv_neutral(1:length(data7_rest2),:),data7_rest2;];
     
data=load('hardware_test_II/experiment_8/data_8.mat');
data8_rest1 = data.data(:,301:600)'; % 5-10 mins: rest 
data8_exercise = data.data(:,601:1200)'; % 10-20 mins: exerices
data8_rest2 = data.data(:,1201:end)'; % 20-30 mins; rest
% Add the corresponding thermal sensation vote
data8 = [tcv_neutral(1:length(data8_rest1),:),data8_rest1;
         tcv_hot(1:length(data8_exercise),:),data8_exercise;
         tcv_neutral(1:length(data8_rest2),:),data8_rest2;];

data=load('hardware_test_II/experiment_9/data_9.mat');
data9_rest1 = data.data(:,302:600)'; % 5-10 mins: rest 
data9_exercise = data.data(:,601:1200)'; % 10-20 mins: exerices
data9_rest2 = data.data(:,1201:end)'; % 20-30 mins; rest
% Add the corresponding thermal sensation vote
data9 = [tcv_neutral(1:length(data9_rest1),:),data9_rest1;
         tcv_hot(1:length(data9_exercise),:),data9_exercise;
         tcv_neutral(1:length(data9_rest2),:),data9_rest2;];

overalldata_inorder2 = [data6;data7;data8;data9];

%%% Shuffle the matrix by row
rowrank = randperm(size(overalldata_inorder2, 1)); % randomly shuffle the row, return the rowrank
overalldata_random2 = overalldata_inorder2(rowrank, :); %%rearrange the data matrix by rowrank

%% Save data into the excel file
% writematrix(overalldata_inorder2,'Data collection.xlsx','Sheet','Inorder','Range','A23403');
% writematrix(overalldata_random2,'Data collection.xlsx','Sheet','Disorder','Range','A23403');
