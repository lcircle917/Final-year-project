clear all; close all
clc

%% Collect exercise data (Experiments 6-9)

% All 4 experiments lasted 30 minutes in total:
% Rest for the first 10 minutes and the last 10 minutes (rest: 0-10 mins + 20-30 mins)
% The middle 10 minutes are under exercise conditions (exercise: 10-20 mins)
% Data is recorded every seconds

% The data of the first 5 minutes is discarded to ensure the reliability of the data because it takes a certain time for the sensor to stabilize
data_len = (30-5)*60;

% thermal sensation vote - 3 scale
tsv_cold=zeros(data_len,1);
tsv_cold(:,:)=-1;
tsv_neutral=zeros(data_len,1);
tsv_neutral(:,:)=0;
tsv_hot=zeros(data_len,1);
tsv_hot(:,:)=1;

% Load and combine data
data=load('hardware_test_II/experiment_6/data_6.mat');
data6_rest1 = data.data(:,301:600)'; % 5-10 mins: rest 
data6_exercise = data.data(:,601:1200)'; % 10-20 mins: exerices
data6_rest2 = data.data(:,1201:end)'; % 20-30 mins; rest
% Add the corresponding thermal sensation vote
data6 = [tsv_neutral(1:length(data6_rest1),:),data6_rest1;
         tsv_hot(1:length(data6_exercise),:),data6_exercise;
         tsv_neutral(1:length(data6_rest2),:),data6_rest2;];

data=load('hardware_test_II/experiment_7/data_7.mat');
data7_rest1 = data.data(:,301:600)'; % 5-10 mins: rest 
data7_exercise = data.data(:,601:1200)'; % 10-20 mins: exerices
data7_rest2 = data.data(:,1201:end)'; % 20-30 mins; rest
% Add the corresponding thermal sensation vote
data7 = [tsv_neutral(1:length(data7_rest1),:),data7_rest1;
         tsv_hot(1:length(data7_exercise),:),data7_exercise;
         tsv_neutral(1:length(data7_rest2),:),data7_rest2;];
     
data=load('hardware_test_II/experiment_8/data_8.mat');
data8_rest1 = data.data(:,301:600)'; % 5-10 mins: rest 
data8_exercise = data.data(:,601:1200)'; % 10-20 mins: exerices
data8_rest2 = data.data(:,1201:end)'; % 20-30 mins; rest
% Add the corresponding thermal sensation vote
data8 = [tsv_neutral(1:length(data8_rest1),:),data8_rest1;
         tsv_hot(1:length(data8_exercise),:),data8_exercise;
         tsv_neutral(1:length(data8_rest2),:),data8_rest2;];

data=load('hardware_test_II/experiment_9/data_9.mat');
data9_rest1 = data.data(:,302:600)'; % 5-10 mins: rest 
data9_exercise = data.data(:,601:1200)'; % 10-20 mins: exerices
data9_rest2 = data.data(:,1201:end)'; % 20-30 mins; rest
% Add the corresponding thermal sensation vote
data9 = [tsv_neutral(1:length(data9_rest1),:),data9_rest1;
         tsv_hot(1:length(data9_exercise),:),data9_exercise;
         tsv_neutral(1:length(data9_rest2),:),data9_rest2;];

overalldata_inorder = [data6;data7;data8;data9];

%%% Shuffle the matrix by row
rowrank = randperm(size(overalldata_inorder, 1)); % randomly shuffle the row, return the rowrank
overalldata_random = overalldata_inorder(rowrank, :); %%rearrange the data matrix by rowrank

writematrix(overalldata_inorder,'Users/apple/Desktop/software/hardware_test_III/Data collection.xlsx','Sheet','Inorder','Range','A23403');
